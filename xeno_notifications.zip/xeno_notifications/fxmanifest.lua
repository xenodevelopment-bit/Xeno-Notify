fx_version 'cerulean'

lua54 'yes'
game 'gta5'
version '1.2.0'
author 'Xeno Development'
description 'ESX Notifications replacement!'

shared_script '@es_extended/imports.lua'

client_scripts { 'Notify.lua', 'client/main.lua' }

ui_page 'nui/index.html'

files {
    'nui/index.html',
    'nui/js/*.js',
    'nui/css/*.css',
}
